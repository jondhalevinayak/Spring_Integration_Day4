package demo;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

@ManagedResource
@Component
public class TestOne {
	
	private String privatestr;
	protected String protectedstr ="Protected String Variable";
	public String publicstr ="Public String Variable";
	
	private String propstr = "prop str var";
	public static String staticstr = "StaticStr";
	
	@ManagedAttribute
	public String getPropstr() {
		return propstr;
	}
	public void setPropstr(String propstr) {
		this.propstr = propstr;
	}
	
	@ManagedOperation
	public void method1(){
		System.out.println("in method1");
	}
	
	@ManagedOperation
	public String method2(){
		System.out.println("in method2");
		return "";
	}
	
	@ManagedOperation()
	@ManagedOperationParameters({
		@ManagedOperationParameter(name="number1", description="The first number"),
		@ManagedOperationParameter(name="number2", description="The second number")
	})
	public int method3(int i, int j){
		System.out.println("in method3");
		return i+j;
	}
}
