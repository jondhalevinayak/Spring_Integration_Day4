package Lab1.Lab1.demo1;

import org.springframework.integration.annotation.Transformer;
import org.springframework.stereotype.Component;

@Component
public class MyTrans {
	
	@Transformer
	public String change(String s){
		return s.toUpperCase();
	}

}
