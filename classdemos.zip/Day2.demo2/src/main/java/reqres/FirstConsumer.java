package reqres;

import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class FirstConsumer {
public static void main(String[] args) {
	String url = "https://reqres.in/api/users/2";
	RestTemplate template = new RestTemplate();
	HttpHeaders headers = new HttpHeaders();
	headers.set("user-agent", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36");
	HttpEntity entity = new HttpEntity("",headers); 

	
	ResponseEntity<String> respentity = template.exchange(url, HttpMethod.GET, entity,String.class);
	if (respentity.getStatusCode()==HttpStatus.OK)
		//respentity.getStatusCodeValue() == 200
	{
	System.out.println("ToString = " + respentity.toString());
	System.out.println("Body = " + respentity.getBody());
	}
}
}
