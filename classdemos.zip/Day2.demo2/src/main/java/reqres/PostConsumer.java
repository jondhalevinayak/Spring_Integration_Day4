package reqres;

import java.io.IOException;
import java.util.Collections;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.util.JSONPObject;
class MyInterceptor1 implements ClientHttpRequestInterceptor{

	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] args, ClientHttpRequestExecution requestexecution)
			throws IOException {
		request.getHeaders().add("user-agent", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36");
		request.getHeaders().setContentType(MediaType.APPLICATION_JSON);
		return requestexecution.execute(request, args);
	}
}
public class PostConsumer {

	public static void main(String[] args) {
		String url = "https://reqres.in/api/users";
		RestTemplate template = new RestTemplate();
		template.setInterceptors(Collections.singletonList(new MyInterceptor1()));
	//	String s = "{    \"name\": \"Vaishali\",  \"job\": \"Trainer\"}";
		User user = new User();
		user.setName("VVV"); user.setJob("TTT" );

		ResponseEntity<String> respentity = template.postForEntity(url,user ,String.class);
		if (respentity.getStatusCode()==HttpStatus.CREATED)
		{
		System.out.println("ToString = " + respentity.toString());
		System.out.println("Body = " + respentity.getBody());
		}

	}

}
