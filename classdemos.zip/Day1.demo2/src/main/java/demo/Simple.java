package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Component;

@Component
public class Simple {
	public Simple(){
		System.out.println("Simple Constructor ");
	}
	
	@Autowired
	private TaskExecutor taskexec;
	
	
	public void m1( int i){
		Runnable r = () ->{
			System.out.println("in runnable of r  using " +  Thread.currentThread().getName() +", for i = " + i);
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};
		taskexec.execute(r);
	}
	
}
