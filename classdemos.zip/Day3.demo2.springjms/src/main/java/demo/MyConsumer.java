package demo;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MyConsumer {
	@JmsListener(destination="AintQueue",containerFactory="myFactory")
	public void receiver(String s){
		System.out.println( "in MyConsumer1 Receiver - " + s);
	}
	
}
