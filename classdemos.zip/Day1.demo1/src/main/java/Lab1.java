import java.util.Scanner;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

class Lab1Helper implements Runnable{
	public Lab1Helper(){
		System.out.println("Lab1Helper constructor ....");
	}
	public void run() {
		System.out.println("in start of  run of Lab1Helper");
		try {
			Thread.sleep(50);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("in end of  run of Lab1Helper");
	}
}
public class Lab1 {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Press a number to continue...");
		scanner.nextInt();
		//Executor executor = Executors.newCachedThreadPool();
		Executor executor = Executors.newFixedThreadPool(5);
		for (int i = 0; i < 2; i++) {
			executor.execute(new Lab1Helper());	
		}

	
	/*	Thread t1= new Thread(new Lab1Helper());
		t1.start();
		*/
	}
	
}
