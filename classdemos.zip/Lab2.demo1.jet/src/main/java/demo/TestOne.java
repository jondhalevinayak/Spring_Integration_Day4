package demo;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

@ManagedResource()
@Component
public class TestOne {
	private String privatestr ="Private String Variable ";
	protected  String protectedstr ="Protected String Variable ";
	

	public String publicstr ="Public String Variable ";
	
	private String propstr="prop str var";
	
	public static String staticstr = "StaticStr";
	
	@ManagedAttribute()
	public String getPropstr() {
		return propstr;
	}
	@ManagedOperation
	public void setPropstr(String propstr) {
		this.propstr = propstr;
	}
	
	public void dummy(){
		System.out.println(" in dummy ...");
	}
	@ManagedOperation
	public void method1(){
		System.out.println(" in method1 ...");
	}
	@ManagedOperation
	public String method2(){
		System.out.println(" in method2 overloaded not inputtype...");
		return "method2";
	}
	@ManagedOperation()
	@ManagedOperationParameters({
	    @ManagedOperationParameter(name = "number1", description = "The first number"),
	    @ManagedOperationParameter(name = "number2", description = "The second number")
	    })
	public int method2(int i, int j){
		System.out.println(" in method2...");
		return i+j;
	}
	
	
}
