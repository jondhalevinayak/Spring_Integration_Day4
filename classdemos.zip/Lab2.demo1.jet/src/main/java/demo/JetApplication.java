package demo;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.context.annotation.ImportResource;


@SpringBootApplication
@EnableMBeanExport(defaultDomain="myd")

@ImportResource("classpath:http-inbound-gateway.xml")
public class JetApplication {
	public static void main(String[] args) {
		SpringApplication.run(JetApplication.class, args);	
	}
}

