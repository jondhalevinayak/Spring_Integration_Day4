package demo;

public class Simple {

}
