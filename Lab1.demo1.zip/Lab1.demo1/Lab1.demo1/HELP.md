# Getting Started

### Guides
The following guides illustrates how to use certain features concretely:

* [Integrating Data](https://spring.io/guides/gs/integration/)

