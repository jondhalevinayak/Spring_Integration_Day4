package Lab1.Lab1.demo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.context.annotation.ImportResource;
import org.springframework.jms.annotation.EnableJms;


@SpringBootApplication
@ImportResource(value="demo1.xml")
@EnableMBeanExport
@EnableJms
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		while(true){
		}
	}
}
